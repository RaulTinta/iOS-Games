//
//  Home.swift
//  Challenge
//

import SwiftUI

struct HomeView: View {
    @EnvironmentObject var customTabViewSettings: CustomTabViewSettings
    @State private var showHomeDetailView = false
    
    var body: some View {
        VStack() {
            Text("Home")
                .font(.title)
                .bold()
            
            Button(action: {
                customTabViewSettings.isTabBarShowing.toggle()
                showHomeDetailView.toggle()
                
            }) {
                Text("Push next")
            }
            .buttonStyle(.bordered)
            
        }
        .navigationDestination(isPresented: $showHomeDetailView, destination: {
            HomeDetailView(showHomeDetailView: $showHomeDetailView)
        })
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.lavender)
        .onAppear {
            customTabViewSettings.isTabBarShowing = true
        }
    }
}

#Preview {
    HomeView()
        .environmentObject(CustomTabViewSettings())
}
