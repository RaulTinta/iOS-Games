//
//  HomeButtonView.swift
//  Challenge
//

import SwiftUI

struct HomeDetailView: View {
    @Binding var showHomeDetailView: Bool
    
    var body: some View {
        VStack() {
            Button(action: {
                showHomeDetailView.toggle()
            }) {
                Text("Back")
            }
            .buttonStyle(.bordered)
            
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.skinTone)
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    HomeDetailView(showHomeDetailView: .constant(true))
}
