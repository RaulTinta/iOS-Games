//
//  History.swift
//  Challenge
//


import SwiftUI

struct HistoryView: View {
    
    @EnvironmentObject var tabBarSettings: TabBarSettings
    @State private var buttonPressed = false
    @State private var buttonText = "Edit"
    
    var body: some View {
        VStack() {
            Text("History")
                .font(.title)
                .bold()
            if buttonPressed {
                Text("Edit Mode on")
            }
            Button(action: {
                tabBarSettings.editMode.toggle()
                buttonPressed.toggle()
                if buttonPressed {
                    buttonText = "Save"
                } else {
                    buttonText = "Edit"
                }
            }, label: {
                Text(buttonText)
            })
            .buttonStyle(.bordered)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.lightGreen)
    }
}

#Preview {
    HistoryView()
        .environmentObject(TabBarSettings())
}
