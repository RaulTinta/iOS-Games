//
//  Profile.swift
//  Challenge
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        VStack() {
            Text("Profile")
                .font(.title)
                .bold()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.beige)
    }
}

#Preview {
    ProfileView()
}
