//
//  Search.swift
//  Challenge
//

import SwiftUI

struct SearchView: View {
    var body: some View {
        VStack() {
            Text("Search")
                .font(.title)
                .bold()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.babyBlue)
    }
}

#Preview {
    SearchView()
}
