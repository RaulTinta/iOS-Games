//
//  Colors.swift
//  Challenge
//

import Foundation
import SwiftUI

extension Color {
    static let babyBlue = Color(red: 184.0/255.0, green: 226.0/255.0, blue: 242.0/255.0)
    static let beige = Color(red: 255.0/255.0, green: 240.0/255.0, blue: 219.0/255.0)
    static let lavender = Color(red: 223.0/255.0, green: 197.0/255.0, blue: 254.0/255.0)
    static let lightGreen = Color(red: 189.0/255.0, green: 242.0/255.0, blue: 184.0/255.0)
    static let skinTone = Color(red: 230.0/255.0, green: 195.0/255.0, blue: 174.0/255.0)
}
