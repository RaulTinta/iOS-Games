//
//  ContentView.swift
//  Challenge
//


import SwiftUI

enum ViewTabs: CaseIterable {
    case home
    case search
    case history
    case profile
}

class CustomTabViewSettings: ObservableObject {
    @Published var isTabBarShowing = true
    
}

struct CustomTabView: View {
    
    @ObservedObject var tabBarSettings = TabBarSettings()
    @ObservedObject var customTabViewSettings = CustomTabViewSettings()
    @State private var selectedTab = TabItem.home

    
    init() {
        UITabBar.appearance().isHidden = true
    }
    
    var body: some View {
        ZStack(alignment: .bottom){
            
            NavigationStack() {
                
                TabView(selection: $selectedTab) {
                    ForEach([TabItem.home, TabItem.search, TabItem.history, TabItem.profile], id: \.self) { tab in
                        VStack() {
                            switch tab{
                            case .home: HomeView()
                            case .search: SearchView()
                            case .history: HistoryView()
                            case .profile: ProfileView()
                            case .back, .delete, .favourite, .unfavourite: EmptyView()
                            }
                        }
                        .safeAreaPadding(.bottom, TabBar.tabBarHeight + 16)
                    }
                }
                .environmentObject(tabBarSettings)
                .environmentObject(customTabViewSettings)
            }
            
            TabBar(tabBarSettings: tabBarSettings, selectedTab: $selectedTab)
                .opacity(customTabViewSettings.isTabBarShowing == true ? 1 : 0)
            
        }

        
    }
}

#Preview {
    CustomTabView()
}
