//
//  TabBar.swift
//  Challenge
//


import SwiftUI

class TabBarSettings: ObservableObject {
    @Published var editMode = false
}

enum TabItem: CaseIterable {
    case home
    case search
    case history
    case profile
    case back
    case delete
    case unfavourite
    case favourite
    
    var imageName: String {
        switch self {
        case .home: return "house.fill"
        case .search: return "magnifyingglass"
        case .history: return "clock"
        case .profile: return "person.fill"
        case .back: return "arrowshape.backward.fill"
        case .delete: return "trash"
        case .unfavourite: return "star.slash.fill"
        case .favourite: return "star.fill"
        }
    }
    
    var color: Color {
        switch self {
        case .delete: return .red
        case .favourite: return .yellow
        default: return .gray
        }
    }
}

struct TabBar: View {
    
    @ObservedObject var tabBarSettings: TabBarSettings
    @Binding var selectedTab: TabItem
    @State var scaleValue = 1.0
    static let tabBarHeight: CGFloat = 70
    
    var body: some View {
        GeometryReader { geometry in
            
            let tabBarWidth = geometry.size.width - 32
            
            ScrollViewReader { proxy in
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack() {
                        
                        viewsTabBar(tabBarWidth: tabBarWidth)
                        
                        editTabBar(tabBarWidth: tabBarWidth)
                        
                    }
                    .onReceive(tabBarSettings.$editMode, perform: { value in
                        withAnimation {
                            value ? proxy.scrollTo("editTabBar") : proxy.scrollTo("viewsTabBar")
                        }
                    })
                }
                .scrollDisabled(false)
            }
            .background(Color.white.opacity(0.7))
            .cornerRadius(16)
            .padding(.horizontal, 16)
        }
        .frame(maxHeight: TabBar.tabBarHeight)
    }
    
    func viewsTabBar(tabBarWidth: CGFloat) -> some View {
        return HStack() {
            ForEach([TabItem.home, TabItem.search, TabItem.history, TabItem.profile], 
                    id: \.self) { tab in
                Image(systemName: tab.imageName)
                    .bold()
                    .scaleEffect(tab == selectedTab ? scaleValue : 1.0)
                    .foregroundStyle(tab == selectedTab ? .blue : .gray)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .font(.system(size: 22))
                    .onTapGesture {
                        selectedTab = tab
                        withAnimation(.linear(duration: 0.1)) {
                            scaleValue = 0.85
                        }
                        withAnimation(.easeIn(duration: 0.1).delay(0.2)) {
                            scaleValue = 1.0
                        }
                    }
            }
        }
        .id("viewsTabBar")
        .frame(width: tabBarWidth)
    }
    
    func editTabBar(tabBarWidth: CGFloat) -> some View {
        return HStack() {
            ForEach([TabItem.back, TabItem.delete, TabItem.unfavourite, TabItem.favourite], id: \.self) { tab in
                Image(systemName: tab.imageName)
                    .bold()
                    .foregroundStyle(tab.color)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .font(.system(size: 22))
                
            }
        }
        .id("editTabBar")
        .frame(width: tabBarWidth)
    }
}



#Preview {
    TabBar(tabBarSettings: TabBarSettings(), selectedTab: .constant(.home))
}
