//
//  ChallengeApp.swift
//  Challenge
//

import SwiftUI

@main
struct ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            CustomTabView()
        }
    }
}
